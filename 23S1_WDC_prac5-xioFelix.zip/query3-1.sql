SELECT *
FROM Subjects;