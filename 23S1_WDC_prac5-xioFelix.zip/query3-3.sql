SELECT given_name, family_name
FROM Students
WHERE program = 'BCompSc';