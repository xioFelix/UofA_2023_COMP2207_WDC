DELETE FROM Enrolments
WHERE student_id = 'a1111112';
DELETE FROM Students
WHERE student_id = 'a1111112';
