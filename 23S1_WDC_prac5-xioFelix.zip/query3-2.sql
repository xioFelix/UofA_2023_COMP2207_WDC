SELECT student_id, program
FROM enrolment.Students;