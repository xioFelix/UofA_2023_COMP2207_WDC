UPDATE Enrolments
SET mark = 50
WHERE student_id = 'a1111113' AND subject_code = 'COMP SCI 1102';